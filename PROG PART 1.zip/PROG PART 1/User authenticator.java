public class Main {
    public class UserAuthenticator {

    /**
     * This method simulates user authentication based on a provided username and password.
     * In a real application, this would involve checking against a database.
     *
     * @param username The username entered by the user.
     * @param password The password entered by the user.
     * @param storedUsername The correct username to check against.
     * @param storedPassword The correct password to check against.
     * @param userFirstName The first name of the user for the welcome message.
     * @param userLastName The last name of the user for the welcome message.
     * @return A string message indicating the result of the authentication attempt.
     */
    public String authenticateUser(String username, String password, String storedUsername, String storedPassword, String userFirstName, String userLastName) {
        
        // Check if the entered username and password match the stored credentials.
        if (username.equals(storedUsername) && password.equals(storedPassword)) {
            // Condition is True: credentials are correct.
            // Return the welcome message as specified in the table.
            return "Welcome " + userFirstName + ", " + userLastName + " it is great to see you again.";
        } else {
            // Condition is False: credentials are incorrect.
            // Return the error message as specified in the table.
            return "Username or password incorrect, please try again.";
        }
    }
}

public class Main {
    public static void main(String[] args) {
        // Create an instance of the UserAuthenticator.
        UserAuthenticator authenticator = new UserAuthenticator();

        // Simulate a successful login attempt.
        String correctUsername = "user123";
        String correctPassword = "password123";
        String userFirstName = "John";
        String userLastName = "Doe";

        String messageSuccess = authenticator.authenticateUser(
            "user123", "password123", correctUsername, correctPassword, userFirstName, userLastName
        );
        System.out.println("Successful Login: " + messageSuccess);

        // Simulate a failed login attempt with an incorrect password.
        String messageFailure = authenticator.authenticateUser(
            "user123", "wrongpass", correctUsername, correctPassword, userFirstName, userLastName
        );
        System.out.println("Failed Login: " + messageFailure);

        // Simulate a failed login attempt with an incorrect username.
        String messageFailure2 = authenticator.authenticateUser(
            "wronguser", "password123", correctUsername, correctPassword, userFirstName, userLastName
        );
        System.out.println("Failed Login: " + messageFailure2);
    }
}


}
