import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

    public class RegistrationValidatorTest {

        @Test
        void testValidUsername() {
            // Test a username that should be correctly formatted [cite: 3]
            assertTrue(RegistrationValidator.isValidUsername("kyl_1"));
        }

        @Test
        void testInvalidUsername() {
            // Test an incorrectly formatted username [cite: 3]
            assertFalse(RegistrationValidator.isValidUsername("kyle!!!!!!!"));
        }

        @Test
        void testValidPassword() {
            // Test a password that meets complexity requirements [cite: 3]
            assertTrue(RegistrationValidator.isValidPassword("Ch&&sec@ke991"));
        }

        @Test
        void testInvalidPassword() {
            // Test a password that does not meet complexity requirements [cite: 3]
            assertFalse(RegistrationValidator.isValidPassword("password"));
        }

        @Test
        void testValidPhoneNumber() {
            // Test a correctly formatted phone number [cite: 3]
            assertTrue(RegistrationValidator.isValidPhoneNumber("+27838968976"));
        }

        @Test
        void testInvalidPhoneNumber() {
            // Test an incorrectly formatted phone number [cite: 3]
            assertFalse(RegistrationValidator.isValidPhoneNumber("08966553"));
        }
    }

}