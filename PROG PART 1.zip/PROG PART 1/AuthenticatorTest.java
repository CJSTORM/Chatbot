import static org.junit.jupiter.api.Assertions.*;

class AuthenticatorTest {
    import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

    public class UserAuthenticatorTest {

        private UserAuthenticator authenticator;
        private final String storedUsername = "user123";
        private final String storedPassword = "password123";
        private final String firstName = "John";
        private final String lastName = "Doe";

        @BeforeEach
        void setUp() {
            authenticator = new UserAuthenticator();
        }

        @Test
        void testSuccessfulLogin() {
            String expectedMessage = "Welcome John, Doe it is great to see you again.";
            String actualMessage = authenticator.authenticateUser(
                    "user123", "password123", storedUsername, storedPassword, firstName, lastName
            );
            assertEquals(expectedMessage, actualMessage);
        }

        @Test
        void testFailedLoginIncorrectPassword() {
            String expectedMessage = "Username or password incorrect, please try again.";
            String actualMessage = authenticator.authenticateUser(
                    "user123", "wrongpass", storedUsername, storedPassword, firstName, lastName
            );
            assertEquals(expectedMessage, actualMessage);
        }

        @Test
        void testFailedLoginIncorrectUsername() {
            String expectedMessage = "Username or password incorrect, please try again.";
            String actualMessage = authenticator.authenticateUser(
                    "wronguser", "password123", storedUsername, storedPassword, firstName, lastName
            );
            assertEquals(expectedMessage, actualMessage);
        }
    }

}