public class Main {
    public class Main {
    public static void main(String[] args) {
        // Create an instance of the UserAuthenticator.
        UserAuthenticator authenticator = new UserAuthenticator();

        // Simulate a successful login attempt.
        String correctUsername = "user123";
        String correctPassword = "password123";
        String userFirstName = "John";
        String userLastName = "Doe";

        String messageSuccess = authenticator.authenticateUser(
                "user123", "password123", correctUsername, correctPassword, userFirstName, userLastName
        );
        System.out.println("Successful Login: " + messageSuccess);

        // Simulate a failed login attempt with an incorrect password.
        String messageFailure = authenticator.authenticateUser(
                "user123", "wrongpass", correctUsername, correctPassword, userFirstName, userLastName
        );
        System.out.println("Failed Login: " + messageFailure);

        // Simulate a failed login attempt with an incorrect username.
        String messageFailure2 = authenticator.authenticateUser(
                "wronguser", "password123", correctUsername, correctPassword, userFirstName, userLastName
        );
        System.out.println("Failed Login: " + messageFailure2);
    }
}
}
