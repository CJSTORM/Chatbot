public class Main {
    import java.util.regex.Matcher;
import java.util.regex.Pattern;

    public class Login {

        private String storedUsername;
        private String storedPassword;

        // This method ensures that the username contains an underscore and is no more than 5 characters.
        public boolean checkUserName(String username) {
            Pattern p = Pattern.compile("^_");
            Matcher m = p.matcher(username);
            return m.find() && username.length() <= 5;
        }

        // This method ensures that the password meets complexity rules.
        public boolean checkPasswordComplexity(String password) {
            // At least 8 characters long, one capital letter, one number, one special character
            String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[^a-zA-Z0-9]).{8,}$";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(password);
            return m.matches();
        }

        // This method ensures that the cell phone is the correct length and contains the international country code.
        // Assuming "correct length" is 12 characters (e.g., +27123456789) and starts with a plus sign.
        public boolean checkCellPhoneNumber(String phoneNumber) {
            String regex = "^\\+[0-9]{11}$"; // Adjust regex based on specific country code requirements
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(phoneNumber);
            return m.matches();
        }

        // This method handles user registration messaging.
        public String registerUser(String username, String password) {
            if (!checkUserName(username)) {
                return "The username is incorrectly formatted.";
            }
            if (!checkPasswordComplexity(password)) {
                return "The password does not meet the complexity requirements.";
            }
            this.storedUsername = username;
            this.storedPassword = password;
            return "The two above conditions have been met, and the user has been registered successfully.";
        }

        // This method verifies that the login details match stored details.
        public boolean loginUser(String username, String password) {
            return username.equals(this.storedUsername) && password.equals(this.storedPassword);
        }

        // This method returns the necessary messaging for login status.
        public String returnLoginStatus(boolean loginSuccessful) {
            if (loginSuccessful) {
                return "A successful login.";
            } else {
                return "A failed login.";
            }
        }
    }


}
