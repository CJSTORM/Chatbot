public class Main {
    import java.util.Scanner;
import java.util.regex.Pattern;


public class RegistrationValidator {


    public static boolean isValidUsername(String username) {
        if (username.length() > 5) {
            return false;
        }
        return username.contains("_");
    }


    public static boolean isValidPassword(String password) {
        String passwordRegex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$";
        Pattern passwordPattern = Pattern.compile(passwordRegex);
        return passwordPattern.matcher(password).matches();
    }


    public static boolean isValidPhoneNumber(String phoneNumber) {
        String phoneRegex = "^\\+27\\d{9,10}$";
        Pattern phonePattern = Pattern.compile(phoneRegex);
        return phonePattern.matcher(phoneNumber).matches();
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        while (true) {
            System.out.println("Please enter a username (no more than 5 characters, must contain an underscore):");
            String username = scanner.nextLine();
            if (isValidUsername(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }


        while (true) {
            System.out.println("Please enter a password (at least 8 chars, must contain a capital letter, a number, and a special character):");
            String password = scanner.nextLine();
            if (isValidPassword(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }


        while (true) {
            System.out.println("Please enter your cell phone number (e.g., +27821234567):");
            String phoneNumber = scanner.nextLine();
            if (isValidPhoneNumber(phoneNumber)) {
                System.out.println("Cell phone number successfully added.");
                break;
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            }
        }


        System.out.println("\nRegistration process complete! Welcome to the application.");
        scanner.close();
    }
}







}
